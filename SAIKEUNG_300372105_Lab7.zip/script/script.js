function addValue(){
    // get the operands value
    var InputA = parseInt(document.getElementById("input_a").value);
    var InputB = parseInt(document.getElementById("input_b").value);
    // parse to integer. You can use: parseInt(input, 10);
    var output = document.mycalculator.output;
    // perform operation
    var result = InputA + InputB;
    // creating the text output
    output.value = InputA + " + " + InputB + " = " + result;
    // (if you want to check) print out in console
    console.log(InputA + " + " + InputB + " = " + result);
    // change the text area
    document.mycalculator.output.value = text;
}


function mulValue(){
        // get the operands value
        var InputA = parseInt(document.getElementById("input_a").value);
        var InputB = parseInt(document.getElementById("input_b").value);
        // parse to integer. You can use: parseInt(input, 10);
        var output = document.mycalculator.output;
        // perform operation
        var result = InputA * InputB;
        // creating the text output
        output.value = InputA + " * " + InputB + " = " + result;
        // (if you want to check) print out in console
        console.log(InputA + " * " + InputB + " = " + result);
        // change the text area
        document.mycalculator.output.value = text;
    }

function divValue(){
        // get the operands value
        var InputA = parseInt(document.getElementById("input_a").value);
        var InputB = parseInt(document.getElementById("input_b").value);
        // parse to integer. You can use: parseInt(input, 10);
        var output = document.mycalculator.output;
        // perform operation
        var result = InputA / InputB;
        // creating the text output
        output.value = InputA + " : " + InputB + " = " + result;
        // (if you want to check) print out in console
        console.log(InputA + " : " + InputB + " = " + result);
        // change the text area
        document.mycalculator.output.value = text;
    }
